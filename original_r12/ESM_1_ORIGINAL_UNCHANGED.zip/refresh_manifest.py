from __future__ import annotations

import csv
import hashlib
from pathlib import Path


ROOT = Path(__file__).resolve().parent
MANIFEST = ROOT / "MANIFEST_SHA256.csv"
GENERATED_SNAPSHOTS = {
    "ARTIFACT_VERIFICATION.json",
    "PORTAL_ARTIFACT_VERIFICATION.json",
    "FULL_ARTIFACT_VERIFICATION.json",
}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest().upper()


def main() -> int:
    paths = sorted(
        (
            path
            for path in ROOT.rglob("*")
            if path.is_file()
            and path.name != MANIFEST.name
            and path.relative_to(ROOT).as_posix() not in GENERATED_SNAPSHOTS
        ),
        key=lambda path: path.relative_to(ROOT).as_posix(),
    )
    with MANIFEST.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(
            handle,
            fieldnames=("path", "sha256", "size"),
            lineterminator="\n",
        )
        writer.writeheader()
        for path in paths:
            writer.writerow(
                {
                    "path": path.relative_to(ROOT).as_posix(),
                    "sha256": sha256(path),
                    "size": path.stat().st_size,
                }
            )
    print(f"WROTE {MANIFEST.name} entries={len(paths)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
