# ECAS 公开补充材料

本目录是由 ECAS 完整审稿 artifact 整理得到的公开补充材料。论文题名为
“ECAS: Evidence-Contracted Construction and Evaluation of LLM-Proposed
Field-Level API Security Policies”，拟投稿期刊为 *Automated Software
Engineering*，作者为 Yi Lv 和 Cheng Wang，通讯作者为 Yi Lv
（lvyi@tongji.edu.cn）。

公开版保留全部最终候选、编译后 proposal、网关决策、统计数字、追溯表、
代码、协议、任务和绘图数据，但移除了 90 份 hosted provider 原始响应封装、
90 份 reasoning traces、150 个生成源目录值和两个 Python 字节码缓存文件。
这些清理没有改变论文数字或科学结论，具体记录见
`PUBLIC_RELEASE_REDACTIONS.json`。

核验命令：

```text
python verify_artifact.py
python -B smoke_import_and_conformance.py
```

第三方来源、权利边界和隐私说明分别见 `THIRD_PARTY_NOTICES.md`、
`LICENSE.md` 和 `PRIVACY_AND_DATA_SCOPE.md`。英文 `README.md` 是公开包的
权威使用说明。
