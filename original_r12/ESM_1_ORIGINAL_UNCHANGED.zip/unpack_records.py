from __future__ import annotations

import base64
import json
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parent


def write_packed_file(destination: Path, record: dict) -> None:
    path = destination / Path(record["path"])
    path.parent.mkdir(parents=True, exist_ok=True)
    if record["encoding"] == "utf-8":
        data = record["content"].encode("utf-8")
    else:
        data = base64.b64decode(record["content_base64"])
    path.write_bytes(data)


def main() -> int:
    if len(sys.argv) != 2:
        print("Usage: python unpack_records.py <destination>")
        return 2
    destination = Path(sys.argv[1]).resolve()
    destination.mkdir(parents=True, exist_ok=True)

    supporting = ROOT / "records" / "supporting_source_records.jsonl"
    for line in supporting.read_text(encoding="utf-8").splitlines():
        if line.strip():
            write_packed_file(destination, json.loads(line))

    for name in (
        "primary_generation_records.jsonl",
        "hosted_generation_records.jsonl",
    ):
        source = ROOT / "records" / name
        for line in source.read_text(encoding="utf-8").splitlines():
            if not line.strip():
                continue
            record = json.loads(line)
            for packed in record["files"].values():
                write_packed_file(destination, packed)

    print(destination)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
