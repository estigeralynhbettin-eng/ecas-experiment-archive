# ECAS public supplementary artifact

**Article title:** ECAS: Evidence-Contracted Construction and Evaluation of
LLM-Proposed Field-Level API Security Policies

**Journal:** Automated Software Engineering

**Authors:** Yi Lv and Cheng Wang

**Corresponding author:** Yi Lv, School of Computer Science and Technology,
Tongji University, Shanghai 201804, China; lvyi@tongji.edu.cn

This package is the public supplementary artifact derived from the full ECAS reviewer
artifact. It preserves the scientific records needed to inspect the reported
methods and results while removing provider-internal response envelopes,
reasoning traces, and transient Python bytecode that are not necessary to
verify the manuscript claims.

## Preserved scientific evidence

- The 30-record primary Qwen3.6 experiment, including its raw model responses,
  candidate seals, and 300 decision rows.
- All 120 hosted-model generation records in normalized candidate form and all
  480 hosted ECAS-P/ECAS decision rows for DeepSeek V4 Pro, GPT-5.6 SOL,
  GLM-5.2, and Kimi K3.
- Protocol locks, schemas, the frozen prompt template, candidate seals,
  independent-validation records, and model-specific configuration records.
- Visible task materials, Evidence Contracts, deterministic baselines, sealed
  evaluation records, security-knowledge catalogs, and operation registries.
- Frozen engine and runner code, result traceability, the claim-evidence matrix,
  figure data, and plotting code.

No candidate, compiled proposal, gateway decision, aggregate count,
traceability row, manuscript claim, or figure datum was changed when preparing
this public package.

## Public-release redactions

The full reviewer artifact remains the byte-preserving review record. This
public package removes the following material from the hosted-model records:

- 90 raw provider response envelopes; and
- 90 provider reasoning-content traces.

It also redacts 150 generation-source directory fields and removes two Python
bytecode cache files. The exact transformation record is stored in
`PUBLIC_RELEASE_REDACTIONS.json`. Normalized candidates, compiled proposals,
receipts, decisions, metrics, and traceability relationships remain available.

## Compact record format

The package stores source records in three JSONL containers:

- `records/primary_generation_records.jsonl`
- `records/hosted_generation_records.jsonl`
- `records/supporting_source_records.jsonl`

Run `python unpack_records.py <destination>` to reconstruct their individual
files. Historical machine paths embedded in immutable provenance records are
non-operational strings. They are not used as package locators and do not
contain a local user-profile name.

## Verification

After unpacking the archive, run:

```text
python verify_artifact.py
python -B smoke_import_and_conformance.py
```

The first command is read-only and checks the manifest, record dimensions,
frozen metrics, traceability relationships, banned file types, and known secret
patterns. The second command checks direct import of the packaged V3 engine and
one fixed allow/deny/fail-closed conformance case. The `-B` option prevents
Python from recreating bytecode caches.

Run `python refresh_manifest.py` only after an intentional package edit, then
rerun both verification commands.

## Rights, third-party sources, and privacy

See `LICENSE.md`, `THIRD_PARTY_NOTICES.md`, and
`PRIVACY_AND_DATA_SCOPE.md`. Upstream excerpts and model/provider names remain
subject to their respective rights and terms; their inclusion does not imply
endorsement.

## Scientific boundary

The primary Qwen3.6 experiment and the four hosted-model experiments were
frozen separately. The hosted results are post-hoc model-sensitivity evidence,
not a single preregistered ranking. The shared 17/21 totals for GPT-5.6 SOL,
GLM-5.2, and Kimi K3 do not represent the same 17 tasks.
