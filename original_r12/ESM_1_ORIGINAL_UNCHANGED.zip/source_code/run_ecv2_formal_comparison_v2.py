#!/usr/bin/env python3
"""Run the single fixed-budget EC-V2 B0/B1/B2/EC-P/EC comparison.

Generation reads only frozen visible prompts.  Hidden Oracle material is opened
only after all 30 raw candidates have been durably frozen and hashed.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import subprocess
import threading
import time
import urllib.request
from pathlib import Path
from typing import Any

from ec_field_security_engine_v3 import PolicyError, compile_model_ir, evaluate


ROOT = Path(__file__).resolve().parents[1]
URL = "http://127.0.0.1:11434/api/chat"
TAGS_URL = "http://127.0.0.1:11434/api/tags"
RUNS = ROOT / "ec_v2_formal_runs"
METHODS = ("B0", "B1", "B2", "EC-P", "EC")


def sha_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest().upper()


def sha_file(path: Path) -> str:
    return sha_bytes(path.read_bytes())


def canonical(value: Any) -> bytes:
    return (
        json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
        + "\n"
    ).encode("utf-8")


def load(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def dump(path: Path, value: Any) -> None:
    path.write_text(
        json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
        newline="\n",
    )


def get_json(url: str) -> Any:
    with urllib.request.urlopen(url, timeout=30) as response:
        return json.loads(response.read())


def post_json(payload: dict[str, Any]) -> tuple[bytes, float]:
    request = urllib.request.Request(
        URL,
        data=json.dumps(payload, ensure_ascii=False).encode("utf-8"),
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    started = time.monotonic()
    with urllib.request.urlopen(request, timeout=600) as response:
        return response.read(), time.monotonic() - started


def monitor_gpu(path: Path, stop: threading.Event) -> None:
    while not stop.is_set():
        result = subprocess.run(
            [
                "nvidia-smi",
                "--query-gpu=timestamp,memory.used,memory.free,utilization.gpu",
                "--format=csv,noheader,nounits",
            ],
            capture_output=True,
            text=True,
            check=False,
        )
        with path.open("a", encoding="utf-8", newline="\n") as handle:
            handle.write(
                json.dumps(
                    {"utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()), "sample": result.stdout.strip()},
                    sort_keys=True,
                )
                + "\n"
            )
        stop.wait(1)


def verify_inventory(lock: dict[str, Any], phase: str) -> list[dict[str, str]]:
    verified = []
    for item in lock["artifact_inventory"]:
        if item["phase"] != phase:
            continue
        path = ROOT / item["path"]
        actual = sha_file(path)
        if actual != item["sha256"]:
            raise RuntimeError(f"artifact hash mismatch: {item['path']}")
        verified.append({"path": item["path"], "sha256": actual})
    return verified


def preflight(lock: dict[str, Any], t0: dict[str, Any], lock_path: Path) -> dict[str, Any]:
    if lock.get("status") != "FROZEN" or lock.get("scientific_result") is not False:
        raise RuntimeError("protocol lock is not frozen")
    if t0.get("status") != "PASS" or t0.get("scientific_result") is not False:
        raise RuntimeError("T0 receipt is not PASS")
    if t0.get("protocol_lock_sha256") != sha_file(lock_path):
        raise RuntimeError("T0 receipt does not bind this protocol lock")
    tags = get_json(TAGS_URL)
    model = next((row for row in tags.get("models", []) if row.get("name") == lock["model"]["name"]), None)
    if not model or model.get("digest", "").upper() != lock["model"]["digest"]:
        raise RuntimeError("model identity mismatch")
    loaded = get_json("http://127.0.0.1:11434/api/ps").get("models", [])
    if loaded:
        raise RuntimeError("T0 requires Ollama to begin unloaded")
    containers = subprocess.run(
        ["wsl", "-d", "Ubuntu", "--", "docker", "ps", "-aq"],
        capture_output=True,
        text=True,
        check=True,
    ).stdout.split()
    if containers:
        raise RuntimeError("T0 requires zero Docker containers")
    gpu = subprocess.run(
        ["nvidia-smi", "--query-gpu=memory.used,utilization.gpu", "--format=csv,noheader,nounits"],
        capture_output=True,
        text=True,
        check=True,
    ).stdout.strip()
    memory, utilization = [int(part.strip()) for part in gpu.split(",")[-2:]]
    if memory > lock["t0_thresholds"]["gpu_memory_used_mib_max"] or utilization > lock["t0_thresholds"]["gpu_utilization_percent_max"]:
        raise RuntimeError("GPU is not at T0 baseline")
    prior = list(RUNS.glob("ecv2-formal-v2-*")) if RUNS.exists() else []
    if any((item / "candidate_freeze.json").exists() for item in prior):
        raise RuntimeError("formal-run-once gate: a candidate freeze already exists")
    return {"gpu_memory_used_mib": memory, "gpu_utilization_percent": utilization, "docker_containers": 0, "ollama_loaded": 0}


def no_policy_result(reason: str) -> dict[str, Any]:
    return {"decision": "deny", "fail_closed": True, "reason": reason, "violations": []}


def evaluate_method(
    method: str,
    task: str,
    envelope: dict[str, Any],
    proposal: dict[str, Any] | None,
    contract: dict[str, Any],
    baselines: Path,
    baseline_pairs: set[tuple[str, str]] | None = None,
) -> dict[str, Any]:
    if method == "B0":
        return {"decision": "allow", "fail_closed": False, "reason": "no_ec_passthrough", "violations": []}
    if method in {"B1", "B2"}:
        path = baselines / method / task / "policy.json"
        if (baseline_pairs is not None and (method, task) not in baseline_pairs) or not path.exists():
            return no_policy_result("no_deterministic_policy_fail_closed")
        return evaluate(load(path), contract, envelope, admission_mode="semantic")
    if proposal is None:
        return no_policy_result("invalid_model_ir_fail_closed")
    if proposal.get("decision") == "abstain":
        return no_policy_result("proposal_abstained_fail_closed")
    mode = "shape_only" if method == "EC-P" else "semantic"
    return evaluate(proposal["policy"], contract if mode == "semantic" else None, envelope, admission_mode=mode)


def family_maps() -> dict[str, str]:
    result: dict[str, str] = {}
    for path, key in [
        (ROOT / "ec_v2_exploration" / "EC_V2_CANDIDATE_CONSTRAINT_MATRIX_20260714.csv", "semantic_family"),
        (ROOT / "ec_v2_exploration" / "EC_V2_FIELD_VALIDATION_DEBT_MATRIX_20260714.csv", "rule_family"),
    ]:
        with path.open(encoding="utf-8-sig", newline="") as handle:
            for row in csv.DictReader(handle):
                result[row["candidate_id"]] = row[key]
    return result


def summarize(rows: list[dict[str, Any]], task_meta: dict[str, dict[str, Any]]) -> dict[str, Any]:
    positives = {task for task, meta in task_meta.items() if meta["expected_proposal_class"] == "propose"}
    controls = set(task_meta) - positives
    metrics: dict[str, Any] = {}
    for method in METHODS:
        subset = [row for row in rows if row["method"] == method and row["task_window_id"] in positives]
        ol = [row for row in subset if row["oracle_channel"] == "O-L"]
        oi = [row for row in subset if row["oracle_channel"] == "O-I"]
        metrics[method] = {
            "proposal_ready_tasks": len(positives),
            "legitimate_allowed": sum(row["decision"] == "allow" for row in ol),
            "legitimate_coverage": sum(row["decision"] == "allow" for row in ol) / len(ol),
            "unsafe_auto_allowed": sum(row["decision"] == "allow" for row in oi),
            "unsafe_auto_allow_rate": sum(row["decision"] == "allow" for row in oi) / len(oi),
            "oracle_accuracy": sum(row["decision"] == row["expected_class"] for row in subset) / len(subset),
        }
    ec = metrics["EC"]
    baseline = metrics["B2"]
    gain_pp = 100 * (ec["legitimate_coverage"] - baseline["legitimate_coverage"])
    safety_delta_pp = 100 * (ec["unsafe_auto_allow_rate"] - baseline["unsafe_auto_allow_rate"])
    if baseline["unsafe_auto_allow_rate"] > 0:
        unsafe_reduction = (baseline["unsafe_auto_allow_rate"] - ec["unsafe_auto_allow_rate"]) / baseline["unsafe_auto_allow_rate"]
    else:
        unsafe_reduction = None
    b2 = {(row["task_window_id"], row["oracle_channel"]): row for row in rows if row["method"] == "B2"}
    ec_rows = {(row["task_window_id"], row["oracle_channel"]): row for row in rows if row["method"] == "EC"}
    improved = sorted(
        task
        for task in positives
        if b2[(task, "O-L")]["decision"] == "deny"
        and ec_rows[(task, "O-L")]["decision"] == "allow"
        and ec_rows[(task, "O-I")]["decision"] == "deny"
    )
    systems = sorted({task_meta[task]["system"] for task in improved})
    families = sorted({family for task in improved for family in task_meta[task]["families"]})
    route_a = gain_pp >= 5.0 and safety_delta_pp <= 0.0
    coverage_drop_pp = 100 * (baseline["legitimate_coverage"] - ec["legitimate_coverage"])
    route_b = unsafe_reduction is not None and unsafe_reduction >= 0.50 and coverage_drop_pp <= 2.0
    representative = len(improved) >= 2 and len(systems) >= 2 and len(families) >= 3
    broad_gate = (route_a or route_b) and representative
    return {
        "methods": metrics,
        "control_tasks": len(controls),
        "ec_vs_b2": {
            "legitimate_coverage_gain_percentage_points": gain_pp,
            "unsafe_auto_allow_delta_percentage_points": safety_delta_pp,
            "unsafe_auto_allow_relative_reduction": unsafe_reduction,
            "route_a_pass": route_a,
            "route_b_pass": route_b,
            "improved_safe_tasks": improved,
            "improved_systems": systems,
            "improved_families": families,
            "representativeness_pass": representative,
            "broad_llm_benefit_gate_pass": broad_gate,
            "stop_llm_benefit_route": not broad_gate,
        },
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--lock", required=True, type=Path)
    parser.add_argument("--t0-receipt", required=True, type=Path)
    args = parser.parse_args()
    lock_path = args.lock.resolve()
    t0_path = args.t0_receipt.resolve()
    lock, t0 = load(lock_path), load(t0_path)
    pre_visible = verify_inventory(lock, "pre_generation_visible")
    environment = preflight(lock, t0, lock_path)

    run_id = "ecv2-formal-v2-" + time.strftime("%Y%m%dT%H%M%SZ", time.gmtime())
    RUNS.mkdir(exist_ok=True)
    out = RUNS / run_id
    out.mkdir()
    calls_dir = out / "generation"
    calls_dir.mkdir()
    visible_root = ROOT / lock["paths"]["visible_root"]
    schema_path = ROOT / lock["paths"]["model_ir_schema"]
    schema = load(schema_path)
    visible_manifest = load(visible_root.parent / "VISIBLE_BUNDLE_MANIFEST.json")
    tasks = [row["task_window_id"] for row in visible_manifest["tasks"]]
    if len(tasks) != 30 or len(set(tasks)) != 30:
        raise RuntimeError("formal task universe must contain 30 unique tasks")
    for row in visible_manifest["tasks"]:
        task = row["task_window_id"]
        if sha_file(visible_root / task / "prompt.txt") != row["prompt_sha256"]:
            raise RuntimeError(f"visible prompt hash mismatch: {task}")
        if sha_file(visible_root / task / "visible_input.json") != row["visible_input_sha256"]:
            raise RuntimeError(f"visible input hash mismatch: {task}")
    contract_root = ROOT / lock["paths"]["contract_root"]
    contract_manifest = load(contract_root / "EVIDENCE_CONTRACT_REPOSITORY_MANIFEST.json")
    for row in contract_manifest["tasks"]:
        if sha_file(contract_root / row["task_window_id"] / "evidence_contract.json") != row["contract_sha256"]:
            raise RuntimeError(f"evidence contract hash mismatch: {row['task_window_id']}")
    baseline_root = ROOT / lock["paths"]["baseline_root"]
    baseline_manifest_pre = load(baseline_root / "DETERMINISTIC_BASELINE_MANIFEST.json")
    for row in baseline_manifest_pre["records"]:
        if sha_file(baseline_root / row["method"] / row["task_window_id"] / "policy.json") != row["sha256"]:
            raise RuntimeError(f"deterministic baseline hash mismatch: {row['method']}:{row['task_window_id']}")
    plan = {
        "run_id": run_id,
        "classification": "single_fixed_budget_formal_comparison",
        "scientific_result": True,
        "protocol_lock_sha256": sha_file(lock_path),
        "t0_receipt_sha256": sha_file(t0_path),
        "hidden_access_before_candidate_freeze": False,
        "methods": METHODS,
        "task_count": len(tasks),
        "model_calls": len(tasks),
        "settings": lock["model"]["settings"],
        "environment": environment,
        "pre_generation_visible_inventory": pre_visible,
    }
    dump(out / "run_plan.json", plan)
    (out / "STATUS.txt").write_text("S10_GENERATING_VISIBLE_ONLY\n", encoding="utf-8")

    stop = threading.Event()
    gpu_thread = threading.Thread(target=monitor_gpu, args=(out / "gpu_samples.jsonl", stop), daemon=True)
    gpu_thread.start()
    candidates: dict[str, dict[str, Any]] = {}
    generation_failure: str | None = None
    try:
        for index, task in enumerate(tasks, 1):
            prompt = (visible_root / task / "prompt.txt").read_text(encoding="utf-8")
            payload = {
                "model": lock["model"]["name"],
                "messages": [{"role": "user", "content": prompt}],
                "stream": False,
                "think": False,
                "format": schema,
                "keep_alive": "15m",
                "options": {
                    "temperature": 0,
                    "seed": 17,
                    "top_p": 1.0,
                    "num_ctx": 32768,
                    "num_predict": 1024,
                },
            }
            call_dir = calls_dir / f"{index:02d}_{task}"
            call_dir.mkdir()
            dump(call_dir / "request_audit.json", {"prompt_sha256": sha_bytes(prompt.encode()), "prompt_bytes": len(prompt.encode()), "schema_sha256": sha_file(schema_path), "retry": 0})
            raw, latency = post_json(payload)
            (call_dir / "raw_response.json").write_bytes(raw)
            envelope = json.loads(raw)
            if envelope.get("done") is not True or envelope.get("done_reason") != "stop":
                raise RuntimeError(f"{task}: incomplete model response")
            message = envelope.get("message", {})
            if message.get("thinking"):
                raise RuntimeError(f"{task}: unexpected thinking channel")
            content = message.get("content", "")
            (call_dir / "candidate_content.txt").write_text(content, encoding="utf-8", newline="\n")
            candidate = None
            proposal = None
            output_error = None
            try:
                candidate = json.loads(content)
                dump(call_dir / "candidate.json", candidate)
                proposal = compile_model_ir(candidate)
                dump(call_dir / "compiled_proposal.json", proposal)
            except (json.JSONDecodeError, PolicyError, TypeError, ValueError) as exc:
                output_error = str(exc)
            record = {
                "call_index": index,
                "task_window_id": task,
                "prompt_sha256": sha_bytes(prompt.encode()),
                "raw_content_sha256": sha_bytes(content.encode()),
                "candidate_sha256": sha_bytes(canonical(candidate)) if candidate is not None else None,
                "decision": candidate.get("decision") if isinstance(candidate, dict) else None,
                "model_ir_valid": proposal is not None,
                "output_error": output_error,
                "latency_seconds": round(latency, 3),
                "prompt_eval_count": envelope.get("prompt_eval_count"),
                "eval_count": envelope.get("eval_count"),
            }
            dump(call_dir / "generation_receipt.json", record)
            candidates[task] = {"candidate": candidate, "proposal": proposal, "record": record}
            dump(out / "generation_progress.json", {"completed": index, "planned": len(tasks), "last_task": task})
            print(json.dumps({"stage": "generation", "completed": index, "planned": len(tasks), "task": task, "decision": record["decision"], "model_ir_valid": record["model_ir_valid"], "latency_seconds": record["latency_seconds"]}), flush=True)
    except Exception as exc:
        generation_failure = repr(exc)
    finally:
        stop.set()
        gpu_thread.join(timeout=10)
    if generation_failure:
        dump(out / "environment_or_transport_failure.json", {"scientific_result": False, "failure": generation_failure, "completed": len(candidates)})
        (out / "STATUS.txt").write_text("S19_ABORTED_BEFORE_HIDDEN\n", encoding="utf-8")
        return 2
    freeze = {
        "freeze_id": "ECV2-FORMAL-CANDIDATE-FREEZE-V2",
        "scientific_result": True,
        "completed_model_calls": len(candidates),
        "retry_count": 0,
        "hidden_materials_read": False,
        "candidates": [candidates[task]["record"] for task in tasks],
    }
    dump(out / "candidate_freeze.json", freeze)
    (out / "STATUS.txt").write_text("S20_CANDIDATES_FROZEN_HIDDEN_MAY_OPEN\n", encoding="utf-8")

    hidden_verified = verify_inventory(lock, "post_candidate_hidden")
    hidden_root = ROOT / lock["paths"]["hidden_root"]
    hidden_manifest = load(hidden_root / "HIDDEN_ORACLE_REPOSITORY_MANIFEST.json")
    family_by_candidate = family_maps()
    task_meta: dict[str, dict[str, Any]] = {}
    for item in hidden_manifest["tasks"]:
        task = item["task_window_id"]
        oracle_manifest_path = hidden_root / "hidden" / task / "oracle_manifest.json"
        binding_path = hidden_root / "bindings" / task / "oracle_binding.json"
        oracle_task_manifest = load(oracle_manifest_path)
        if sha_file(oracle_manifest_path) != item["manifest_sha256"]:
            raise RuntimeError(f"hidden task manifest hash mismatch: {task}")
        if sha_file(binding_path) != item["binding_sha256"]:
            raise RuntimeError(f"hidden binding hash mismatch: {task}")
        if sha_file(hidden_root / "hidden" / task / "O-L.json") != oracle_task_manifest["ol_sha256"]:
            raise RuntimeError(f"hidden O-L hash mismatch: {task}")
        if sha_file(hidden_root / "hidden" / task / "O-I.json") != oracle_task_manifest["oi_sha256"]:
            raise RuntimeError(f"hidden O-I hash mismatch: {task}")
        families = sorted({family_by_candidate[cid] for cid in oracle_task_manifest["candidate_ids"] if cid in family_by_candidate})
        task_meta[task] = {**item, "families": families}
    baselines = ROOT / lock["paths"]["baseline_root"]
    baseline_manifest = load(baselines / "DETERMINISTIC_BASELINE_MANIFEST.json")
    baseline_pairs = {
        (item["method"], item["task_window_id"])
        for item in baseline_manifest["records"]
    }
    contracts = ROOT / lock["paths"]["contract_root"]
    rows: list[dict[str, Any]] = []
    for task in tasks:
        contract = load(contracts / task / "evidence_contract.json")
        proposal = candidates[task]["proposal"]
        for channel in ("O-L", "O-I"):
            oracle = load(hidden_root / "hidden" / task / f"{channel}.json")
            for vector in oracle["vectors"]:
                for method in METHODS:
                    result = evaluate_method(method, task, vector["envelope"], proposal, contract, baselines, baseline_pairs)
                    rows.append(
                        {
                            "task_window_id": task,
                            "system": task_meta[task]["system"],
                            "track": task_meta[task]["track"],
                            "families": task_meta[task]["families"],
                            "expected_proposal_class": task_meta[task]["expected_proposal_class"],
                            "method": method,
                            "oracle_channel": channel,
                            "vector_id": vector["vector_id"],
                            "expected_class": vector["expected_class"],
                            "decision": result["decision"],
                            "correct": result["decision"] == vector["expected_class"],
                            "fail_closed": result.get("fail_closed"),
                            "engine_error": result.get("engine_error"),
                            "reason": result.get("reason"),
                        }
                    )
    with (out / "result_rows.jsonl").open("w", encoding="utf-8", newline="\n") as handle:
        for row in rows:
            handle.write(json.dumps(row, ensure_ascii=False, sort_keys=True) + "\n")
    metrics = summarize(rows, task_meta)
    dump(out / "method_metrics.json", metrics)
    summary = {
        **plan,
        "status": "COMPLETE",
        "hidden_access_after_candidate_freeze": True,
        "hidden_inventory_verified": hidden_verified,
        "candidate_freeze_sha256": sha_file(out / "candidate_freeze.json"),
        "result_rows_sha256": sha_file(out / "result_rows.jsonl"),
        "method_metrics_sha256": sha_file(out / "method_metrics.json"),
        "candidate_byte_identity_ecp_ec": True,
        "formal_model_calls": len(candidates),
        "formal_retries": 0,
        "stop_gate": metrics["ec_vs_b2"],
    }
    dump(out / "formal_summary.json", summary)
    inventory = []
    for path in sorted(item for item in out.rglob("*") if item.is_file() and item.name != "sha256_inventory.txt"):
        inventory.append(f"{sha_file(path)}  {path.relative_to(out).as_posix()}")
    (out / "sha256_inventory.txt").write_text("\n".join(inventory) + "\n", encoding="utf-8", newline="\n")
    (out / "STATUS.txt").write_text("S30_FORMAL_COMPLETE\n", encoding="utf-8")
    print(json.dumps({"stage": "complete", "run_id": run_id, "metrics": metrics, "formal_summary_sha256": sha_file(out / "formal_summary.json")}, indent=2), flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
