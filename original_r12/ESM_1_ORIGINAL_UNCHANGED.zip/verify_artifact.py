from __future__ import annotations

import csv
import hashlib
import json
import re
import sys
from collections import defaultdict
from pathlib import Path


ROOT = Path(__file__).resolve().parent


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest().upper()


def load_jsonl(path: Path) -> list[dict]:
    return [
        json.loads(line)
        for line in path.read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]


def packed_bytes(record: dict) -> bytes:
    if record["encoding"] == "utf-8":
        return record["content"].encode("utf-8")
    import base64

    return base64.b64decode(record["content_base64"])


def verify_traceability(errors: list[str]) -> dict[str, int]:
    claim_path = ROOT / "traceability" / "CLAIM_EVIDENCE_MATRIX.csv"
    result_path = ROOT / "traceability" / "RESULT_TRACEABILITY.csv"
    if not claim_path.is_file():
        errors.append("missing traceability/CLAIM_EVIDENCE_MATRIX.csv")
        return {"claim_rows": 0, "result_rows": 0, "referenced_result_ids": 0}
    if not result_path.is_file():
        errors.append("missing traceability/RESULT_TRACEABILITY.csv")
        return {"claim_rows": 0, "result_rows": 0, "referenced_result_ids": 0}

    with claim_path.open(encoding="utf-8-sig", newline="") as handle:
        claim_reader = csv.DictReader(handle)
        claim_rows = list(claim_reader)
        claim_headers = set(claim_reader.fieldnames or [])
    with result_path.open(encoding="utf-8-sig", newline="") as handle:
        result_reader = csv.DictReader(handle)
        result_rows = list(result_reader)
        result_headers = set(result_reader.fieldnames or [])

    required_claim_headers = {
        "claim_id",
        "claim_class",
        "manuscript_file",
        "section",
        "locator",
        "claim_text",
        "number_as_written",
        "number_type",
        "result_id",
        "source_artifact",
        "source_locator",
        "derived_table_or_figure",
        "verification_status",
        "severity",
        "verified_by",
        "verified_at",
        "legacy_locator",
        "notes",
    }
    required_result_headers = {
        "result_id",
        "experiment_id",
        "metric_name",
        "source_output_path",
        "source_locator",
        "status",
        "verified_by",
        "verified_at",
    }
    missing_claim_headers = sorted(required_claim_headers - claim_headers)
    missing_result_headers = sorted(required_result_headers - result_headers)
    if missing_claim_headers:
        errors.append("claim matrix missing fields: " + ", ".join(missing_claim_headers))
    if missing_result_headers:
        errors.append(
            "result traceability missing fields: " + ", ".join(missing_result_headers)
        )

    claim_ids = [row.get("claim_id", "").strip() for row in claim_rows]
    duplicate_claim_ids = sorted(
        claim_id for claim_id in set(claim_ids) if claim_ids.count(claim_id) > 1
    )
    if duplicate_claim_ids:
        errors.append("duplicate claim_id values: " + ", ".join(duplicate_claim_ids))
    for index, row in enumerate(claim_rows, start=2):
        blank_fields = sorted(
            field
            for field in required_claim_headers
            if not str(row.get(field, "")).strip()
        )
        if blank_fields:
            errors.append(
                f"claim matrix row {index} has blank fields: {', '.join(blank_fields)}"
            )

    result_ids = [row.get("result_id", "").strip() for row in result_rows]
    duplicate_result_ids = sorted(
        result_id for result_id in set(result_ids) if result_ids.count(result_id) > 1
    )
    if duplicate_result_ids:
        errors.append("duplicate result_id values: " + ", ".join(duplicate_result_ids))
    result_by_id = {
        row.get("result_id", "").strip(): row
        for row in result_rows
        if row.get("result_id", "").strip()
    }

    drive_absolute = re.compile(r"[A-Za-z]:[\\/]")
    for row in claim_rows:
        for field in ("manuscript_file", "source_artifact"):
            if drive_absolute.search(str(row.get(field, ""))):
                errors.append(
                    f"claim {row.get('claim_id')} uses drive-qualified {field}"
                )
    for row in result_rows:
        for field in ("source_output_path", "script_path", "command_or_config"):
            if drive_absolute.search(str(row.get(field, ""))):
                errors.append(
                    f"result {row.get('result_id')} uses drive-qualified {field}"
                )

    referenced_ids: set[str] = set()
    for row in claim_rows:
        raw_reference = row.get("result_id", "").strip()
        if raw_reference == "N/A":
            continue
        parts = [part.strip() for part in raw_reference.split("|") if part.strip()]
        if not parts or "N/A" in parts:
            errors.append(f"invalid result_id expression for {row.get('claim_id')}")
            continue
        referenced_ids.update(parts)

    referenced_required_fields = {
        "experiment_id",
        "metric_name",
        "source_output_path",
        "source_locator",
        "status",
        "verified_by",
        "verified_at",
    }
    for result_id in sorted(referenced_ids):
        result = result_by_id.get(result_id)
        if result is None:
            errors.append(f"claim matrix references missing result_id: {result_id}")
            continue
        blank_fields = sorted(
            field
            for field in referenced_required_fields
            if not str(result.get(field, "")).strip()
        )
        if blank_fields:
            errors.append(
                f"referenced result {result_id} has blank fields: "
                + ", ".join(blank_fields)
            )
        source_paths = [
            part.strip()
            for part in result.get("source_output_path", "").split("|")
            if part.strip()
        ]
        if any(drive_absolute.search(path) for path in source_paths):
            errors.append(f"referenced result uses absolute source path: {result_id}")

    return {
        "claim_rows": len(claim_rows),
        "result_rows": len(result_rows),
        "referenced_result_ids": len(referenced_ids),
    }


def main() -> int:
    errors: list[str] = []

    traceability = verify_traceability(errors)

    manifest_path = ROOT / "MANIFEST_SHA256.csv"
    with manifest_path.open(encoding="utf-8", newline="") as handle:
        manifest = list(csv.DictReader(handle))
    manifest_paths = [row["path"].replace("\\", "/") for row in manifest]
    duplicate_manifest_paths = sorted(
        path for path in set(manifest_paths) if manifest_paths.count(path) > 1
    )
    if duplicate_manifest_paths:
        errors.append(
            "duplicate manifest paths: " + ", ".join(duplicate_manifest_paths)
        )
    for row in manifest:
        path = ROOT / Path(row["path"])
        if not path.is_file():
            errors.append(f"missing manifest file: {row['path']}")
            continue
        observed = sha256_bytes(path.read_bytes())
        if observed != row["sha256"].upper():
            errors.append(f"manifest mismatch: {row['path']}")
    generated_snapshots = {
        "ARTIFACT_VERIFICATION.json",
        "PORTAL_ARTIFACT_VERIFICATION.json",
        "FULL_ARTIFACT_VERIFICATION.json",
    }
    forbidden_snapshot_entries = sorted(generated_snapshots & set(manifest_paths))
    if forbidden_snapshot_entries:
        errors.append(
            "generated verification snapshots must not be manifest inputs: "
            + ", ".join(forbidden_snapshot_entries)
        )
    expected_manifest_paths = {
        path.relative_to(ROOT).as_posix()
        for path in ROOT.rglob("*")
        if path.is_file()
        and path.name != "MANIFEST_SHA256.csv"
        and path.relative_to(ROOT).as_posix() not in generated_snapshots
    }
    if set(manifest_paths) != expected_manifest_paths:
        missing_from_manifest = sorted(expected_manifest_paths - set(manifest_paths))
        stale_manifest_entries = sorted(set(manifest_paths) - expected_manifest_paths)
        if missing_from_manifest:
            errors.append(
                "files omitted from manifest: " + ", ".join(missing_from_manifest)
            )
        if stale_manifest_entries:
            errors.append(
                "stale manifest entries: " + ", ".join(stale_manifest_entries)
            )

    primary_generation = load_jsonl(
        ROOT / "records" / "primary_generation_records.jsonl"
    )
    hosted_generation = load_jsonl(
        ROOT / "records" / "hosted_generation_records.jsonl"
    )
    supporting = load_jsonl(
        ROOT / "records" / "supporting_source_records.jsonl"
    )

    if len(primary_generation) != 30:
        errors.append(f"expected 30 primary responses, found {len(primary_generation)}")
    if len(hosted_generation) != 120:
        errors.append(f"expected 120 hosted responses, found {len(hosted_generation)}")
    if len(supporting) != 231:
        errors.append(f"expected 231 supporting source files, found {len(supporting)}")

    for collection in (primary_generation, hosted_generation):
        for record in collection:
            files = record["files"]
            for required in ("candidate_content.txt", "generation_receipt.json"):
                if required not in files:
                    errors.append(f"missing {required}: {record['source_dir']}")
                    continue
                packed = files[required]
                data = packed_bytes(packed)
                if sha256_bytes(data) != packed["sha256"]:
                    errors.append(f"packed hash mismatch: {packed['path']}")
                if required == "candidate_content.txt" and not data.strip():
                    errors.append(f"empty candidate content: {packed['path']}")
            for packed in files.values():
                if sha256_bytes(packed_bytes(packed)) != packed["sha256"]:
                    errors.append(f"packed hash mismatch: {packed['path']}")

    for packed in supporting:
        if sha256_bytes(packed_bytes(packed)) != packed["sha256"]:
            errors.append(f"supporting packed hash mismatch: {packed['path']}")

    primary_rows = load_jsonl(ROOT / "results" / "primary_result_rows.jsonl")
    if len(primary_rows) != 300:
        errors.append(f"expected 300 primary rows, found {len(primary_rows)}")
    expected_primary = {
        "B0": (21, 21),
        "B1": (3, 0),
        "B2": (4, 0),
        "EC-P": (10, 2),
        "EC": (9, 2),
    }
    primary_metrics = {}
    for method, expected in expected_primary.items():
        rows = [
            row
            for row in primary_rows
            if row.get("method") == method
            and row.get("expected_proposal_class") == "propose"
        ]
        legitimate = sum(
            row.get("oracle_channel") == "O-L" and row.get("decision") == "allow"
            for row in rows
        )
        unsafe = sum(
            row.get("oracle_channel") == "O-I" and row.get("decision") == "allow"
            for row in rows
        )
        primary_metrics[method] = {
            "legitimate_allowed": legitimate,
            "unsafe_auto_allowed": unsafe,
        }
        if (legitimate, unsafe) != expected:
            errors.append(f"primary metric mismatch: {method}")

    hosted_rows = []
    for path in sorted((ROOT / "results" / "hosted").glob("*_result_rows.jsonl")):
        hosted_rows.extend(load_jsonl(path))
    if len(hosted_rows) != 480:
        errors.append(f"expected 480 hosted rows, found {len(hosted_rows)}")

    expected_hosted = {
        "deepseek-v4-pro-thinking-high": (14, 4, 8, 9),
        "gpt-5.6-sol-high": (17, 0, 7, 9),
        "glm-5.2-thinking": (17, 2, 6, 9),
        "kimi-k3-thinking-high": (17, 2, 7, 9),
    }
    hosted_metrics = {}
    for arm_id, expected in expected_hosted.items():
        arm_rows = [row for row in hosted_rows if row.get("arm_id") == arm_id]
        if len(arm_rows) != 120:
            errors.append(f"expected 120 rows for {arm_id}, found {len(arm_rows)}")
            continue
        positive = [
            row for row in arm_rows if row.get("expected_proposal_class") == "propose"
        ]
        legitimate = sum(
            row.get("method") == "EC"
            and row.get("oracle_channel") == "O-L"
            and row.get("decision") == "allow"
            for row in positive
        )
        unsafe = sum(
            row.get("method") == "EC"
            and row.get("oracle_channel") == "O-I"
            and row.get("decision") == "allow"
            for row in positive
        )
        controls = [
            row for row in arm_rows if row.get("expected_proposal_class") == "abstain"
        ]
        closure = {}
        for method in ("EC-P", "EC"):
            by_task: dict[str, set[str]] = defaultdict(set)
            for row in controls:
                if row.get("method") == method:
                    by_task[row["task_window_id"]].add(row["decision"])
            closure[method] = sum(values == {"deny"} for values in by_task.values())
        observed = (legitimate, unsafe, closure["EC-P"], closure["EC"])
        hosted_metrics[arm_id] = {
            "legitimate_allowed": legitimate,
            "unsafe_auto_allowed": unsafe,
            "ecp_control_closure": closure["EC-P"],
            "ec_control_closure": closure["EC"],
        }
        if observed != expected:
            errors.append(f"hosted metric mismatch: {arm_id}")

    banned_suffixes = {
        ".exe",
        ".dll",
        ".bat",
        ".cmd",
        ".ps1",
        ".jks",
        ".pem",
        ".pyc",
    }
    banned_parts = {"smoke", "runtime_smoke", "__pycache__", "__macosx", ".git"}
    for path in ROOT.rglob("*"):
        if not path.is_file():
            continue
        rel = path.relative_to(ROOT)
        if path.suffix.lower() in banned_suffixes:
            errors.append(f"banned file type: {rel.as_posix()}")
        if any(part.lower() in banned_parts for part in rel.parts):
            errors.append(f"banned path component: {rel.as_posix()}")

    secret_patterns = [
        re.compile(r"sk-[A-Za-z0-9_-]{16,}"),
        re.compile(r"Bearer\s+[A-Za-z0-9._-]{20,}", re.IGNORECASE),
        re.compile(
            r"(?:OPENAI|GLM|KIMI|DEEPL|DEEPSEEK|ANTHROPIC|OPUS5|fable5)"
            r"_API_KEY\s*[:=]\s*[\"'][^\"']{12,}[\"']",
            re.IGNORECASE,
        ),
    ]
    for path in ROOT.rglob("*"):
        if not path.is_file() or path.suffix.lower() not in {
            ".json",
            ".jsonl",
            ".txt",
            ".md",
            ".csv",
            ".py",
        }:
            continue
        text = path.read_text(encoding="utf-8", errors="ignore")
        if any(pattern.search(text) for pattern in secret_patterns):
            errors.append(f"potential secret pattern: {path.relative_to(ROOT)}")

    report = {
        "status": "PASS" if not errors else "FAIL",
        "package_root": ".",
        "package_id": ROOT.name,
        "traceability": traceability,
        "file_count": sum(1 for path in ROOT.rglob("*") if path.is_file()),
        "primary_response_records": len(primary_generation),
        "primary_result_rows": len(primary_rows),
        "hosted_response_records": len(hosted_generation),
        "hosted_result_rows": len(hosted_rows),
        "supporting_source_records": len(supporting),
        "primary_metrics": primary_metrics,
        "hosted_metrics": hosted_metrics,
        "errors": errors,
    }
    report_text = json.dumps(report, ensure_ascii=False, indent=2) + "\n"
    (ROOT / "ARTIFACT_VERIFICATION.json").write_text(
        report_text,
        encoding="utf-8",
        newline="\n",
    )
    print(report_text, end="")
    return 0 if not errors else 1


if __name__ == "__main__":
    raise SystemExit(main())
