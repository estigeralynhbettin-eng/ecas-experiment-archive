from __future__ import annotations

from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import scienceplots  # noqa: F401 -- registers SciencePlots styles


ROOT = Path(__file__).resolve().parents[1]
DATA_DIR = ROOT / "data"
OUT_DIR = ROOT / "figures"

BLUE = "#0072B2"
VERMILLION = "#D55E00"
GRAY_DARK = "#4D4D4D"
GRAY_LIGHT = "#B8B8B8"


def load_and_validate() -> tuple[pd.DataFrame, pd.DataFrame]:
    main = pd.read_csv(DATA_DIR / "main_results.csv")
    closure = pd.read_csv(DATA_DIR / "control_closure.csv")

    expected_methods = ["B0", "B1", "B2", "EC-P", "EC"]
    assert main["method"].tolist() == expected_methods
    assert (main["legitimate_total"] == 21).all()
    assert (main["unsafe_total"] == 21).all()
    assert closure["method"].tolist() == ["EC-P", "EC"]
    assert (closure["control_total"] == 9).all()

    np.testing.assert_allclose(
        main["legitimate_coverage_pct"],
        100 * main["legitimate_allowed"] / main["legitimate_total"],
        atol=5e-4,
    )
    np.testing.assert_allclose(
        main["unsafe_auto_allow_pct"],
        100 * main["unsafe_auto_allowed"] / main["unsafe_total"],
        atol=5e-4,
    )
    np.testing.assert_allclose(
        closure["control_closure_pct"],
        100 * closure["controls_closed"] / closure["control_total"],
        atol=5e-4,
    )
    return main, closure


def annotate_horizontal_counts(ax, bars, numerators, denominators, color):
    for bar, n, d in zip(bars, numerators, denominators, strict=True):
        value = bar.get_width()
        x = value + 1.5 if value > 0 else 1.5
        ax.text(
            x,
            bar.get_y() + bar.get_height() / 2,
            f"{int(n)}/{int(d)}",
            va="center",
            ha="left",
            fontsize=7.2,
            color=color,
        )


def build_figure(main: pd.DataFrame, closure: pd.DataFrame, grayscale: bool = False):
    if grayscale:
        coverage_color, unsafe_color = GRAY_LIGHT, GRAY_DARK
        closure_colors = [GRAY_LIGHT, GRAY_DARK]
    else:
        coverage_color, unsafe_color = BLUE, VERMILLION
        closure_colors = ["#56B4E9", "#009E73"]

    with plt.style.context(["science", "no-latex", "grid"]):
        plt.rcParams.update(
            {
                "font.family": "serif",
                "font.serif": ["Times New Roman", "DejaVu Serif"],
                "font.size": 8,
                "axes.labelsize": 8.5,
                "axes.titlesize": 9,
                "xtick.labelsize": 7.5,
                "ytick.labelsize": 8,
                "legend.fontsize": 7.3,
                "axes.linewidth": 0.7,
                "grid.linewidth": 0.45,
                "grid.alpha": 0.28,
                "hatch.linewidth": 0.7,
            }
        )

        fig, (ax1, ax2) = plt.subplots(
            1,
            2,
            figsize=(7.2, 3.05),
            gridspec_kw={"width_ratios": [1.65, 0.82], "wspace": 0.33},
        )

        y = np.arange(len(main))
        height = 0.34
        coverage = ax1.barh(
            y - height / 2,
            main["legitimate_coverage_pct"],
            height,
            label="Legitimate coverage",
            color=coverage_color,
            edgecolor="black",
            linewidth=0.45,
            hatch="..." if grayscale else None,
        )
        unsafe = ax1.barh(
            y + height / 2,
            main["unsafe_auto_allow_pct"],
            height,
            label="Unsafe automatic allow",
            color=unsafe_color,
            edgecolor="black",
            linewidth=0.45,
            hatch="///",
        )
        annotate_horizontal_counts(
            ax1,
            coverage,
            main["legitimate_allowed"],
            main["legitimate_total"],
            "black",
        )
        annotate_horizontal_counts(
            ax1,
            unsafe,
            main["unsafe_auto_allowed"],
            main["unsafe_total"],
            unsafe_color if not grayscale else "black",
        )
        ax1.set_yticks(y, main["method"])
        ax1.invert_yaxis()
        ax1.set_xlim(0, 112)
        ax1.set_xticks(np.arange(0, 101, 20))
        ax1.set_xlabel("Rate over positive tasks (%)")
        ax1.set_title(
            "(a) Policy-layer safety and coverage outcomes",
            loc="left",
            fontweight="bold",
        )
        ax1.legend(loc="lower right", frameon=True, borderpad=0.35)
        ax1.grid(axis="y", visible=False)

        x = np.arange(len(closure))
        bars = ax2.bar(
            x,
            closure["control_closure_pct"],
            width=0.58,
            color=closure_colors,
            edgecolor="black",
            linewidth=0.55,
        )
        if grayscale:
            bars[0].set_hatch("...")
            bars[1].set_hatch("xxx")
        for bar, n, d in zip(
            bars,
            closure["controls_closed"],
            closure["control_total"],
            strict=True,
        ):
            ax2.text(
                bar.get_x() + bar.get_width() / 2,
                bar.get_height() + 2.0,
                f"{int(n)}/{int(d)}",
                ha="center",
                va="bottom",
                fontsize=8,
                fontweight="bold",
            )
        ax2.set_xticks(x, closure["method"])
        ax2.set_ylim(0, 112)
        ax2.set_yticks(np.arange(0, 101, 20))
        ax2.set_ylabel("Control closure (%)")
        ax2.set_title("(b) Admission control", loc="left", fontweight="bold")
        ax2.grid(axis="x", visible=False)

        fig.subplots_adjust(left=0.085, right=0.985, bottom=0.18, top=0.89)
        return fig


def main() -> None:
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    main_df, closure_df = load_and_validate()

    color_fig = build_figure(main_df, closure_df, grayscale=False)
    color_fig.savefig(OUT_DIR / "fig02_main_results.pdf", bbox_inches="tight")
    color_fig.savefig(OUT_DIR / "fig02_main_results.svg", bbox_inches="tight")
    color_fig.savefig(
        OUT_DIR / "fig02_main_results.png", dpi=600, bbox_inches="tight"
    )
    plt.close(color_fig)

    gray_fig = build_figure(main_df, closure_df, grayscale=True)
    gray_fig.savefig(
        OUT_DIR / "fig02_main_results_grayscale.png", dpi=300, bbox_inches="tight"
    )
    plt.close(gray_fig)

    print("Validated frozen EC-V2 metrics and wrote PDF/SVG/PNG outputs.")


if __name__ == "__main__":
    main()
