from __future__ import annotations

import hashlib
import importlib.util
import json
import sys
from pathlib import Path


sys.dont_write_bytecode = True


ROOT = Path(__file__).resolve().parent
ENGINE_PATH = next(
    path
    for path in (
        ROOT / "scripts" / "ec_field_security_engine_v3.py",
        ROOT / "source_code" / "ec_field_security_engine_v3.py",
    )
    if path.is_file()
)

EXPECTED_V2_SCHEMA_SHA256 = {
    "EC_EVIDENCE_CONTRACT_SCHEMA_V2.json": "4B8E947BFFFD9B95094358F07BCC4CFCFFC44239E260CD12394F57C8FBB6E765",
    "EC_FIELD_SECURITY_MODEL_IR_SCHEMA_V2.json": "055FCFC78027E73CF6D8C71544CA33E63D4D4354F97DCAE29C6F44C12F9C4053",
    "EC_FIELD_SECURITY_POLICY_SCHEMA_V2.json": "077D7BFA1F251B072CC973490C7E600F566B690BF1F155D161D1E33071765B67",
    "EC_FIELD_SECURITY_PROPOSAL_SCHEMA_V2.json": "D22A110C34A2A8ECDE5056CD71585EBE6694724B6E331BEB2CE16B0608046CB4",
}

TARGET = {
    "system": "Fineract",
    "version": "1.14.0",
    "operation": "POST /v1/clients/{clientId}/identifiers",
}
EVIDENCE_ID = "VIS-FSV-S02-01"
POLICY = {
    "policy_version": "EC-FIELD-SECURITY-V3",
    "policy_id": "SMOKE-FSV-S02",
    "target": TARGET,
    "evidence_refs": [EVIDENCE_ID],
    "rules": [
        {
            "rule_id": "SMOKE-FSV-S02-R1",
            "primitive_id": "SP-OBJECT-PROPERTY-ALLOWLIST",
            "evidence_refs": [EVIDENCE_ID],
            "op": "allowed_fields",
            "path": "/request/body",
            "fields": ["description", "documentKey", "documentTypeId", "status"],
            "on_missing": "deny",
        }
    ],
}
CONTRACT = {
    "contract_version": "EC-EVIDENCE-CONTRACT-V3",
    "contract_id": "SMOKE-CONTRACT-FSV-S02",
    "catalog_id": "EC-SECURITY-PRIMITIVE-CATALOG-V2",
    "target": TARGET,
    "evidence": [
        {
            "evidence_id": EVIDENCE_ID,
            "source_kind": "api_documentation",
            "system": "Fineract",
            "versions": ["1.14.0"],
            "operations": [TARGET["operation"]],
            "locator": "paths./v1/clients/{clientId}/identifiers.post",
            "sha256": "A44D6FA247D495A4FB147CC8C5EA1A364D8F05A40762B31A055681373E455A48",
            "visibility": "visible",
            "relation": "supports",
            "supports_primitives": ["SP-OBJECT-PROPERTY-ALLOWLIST"],
            "bound_paths": ["/request/body"],
            "binding_facts": {"visible_request_schema_or_parameter_list": True},
        }
    ],
}
ALLOW_ENVELOPE = {
    "request": {
        "body": {
            "description": "Document has been verified",
            "documentKey": "KA-54677",
            "documentTypeId": 1,
            "status": "Active",
        }
    },
    "trusted": {},
}
DENY_ENVELOPE = {
    "request": {"body": {**ALLOW_ENVELOPE["request"]["body"], "unexpected": True}},
    "trusted": {},
}


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest().upper()


def load_engine():
    spec = importlib.util.spec_from_file_location("_ecas_artifact_smoke_engine", ENGINE_PATH)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"cannot load engine: {ENGINE_PATH}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


def main() -> int:
    schema_hashes = {
        name: sha256(ROOT / name) for name in EXPECTED_V2_SCHEMA_SHA256
    }
    if schema_hashes != EXPECTED_V2_SCHEMA_SHA256:
        raise AssertionError(
            f"V2 dependency hash mismatch: {json.dumps(schema_hashes, sort_keys=True)}"
        )

    engine = load_engine()
    allowed = engine.evaluate(POLICY, CONTRACT, ALLOW_ENVELOPE)
    denied = engine.evaluate(POLICY, CONTRACT, DENY_ENVELOPE)
    malformed = engine.evaluate({"policy_id": "malformed"}, CONTRACT, ALLOW_ENVELOPE)

    if allowed.get("decision") != "allow" or allowed.get("violations") != []:
        raise AssertionError(f"fixed allow case failed: {allowed}")
    if denied.get("decision") != "deny" or not denied.get("violations"):
        raise AssertionError(f"fixed deny case failed: {denied}")
    if malformed.get("decision") != "deny" or "engine_error" not in malformed:
        raise AssertionError(f"fail-closed malformed case failed: {malformed}")

    report = {
        "status": "PASS",
        "engine_path": ENGINE_PATH.relative_to(ROOT).as_posix(),
        "engine_policy_version": engine.core.POLICY_VERSION,
        "catalog_id": engine.core.CATALOG["catalog_id"],
        "catalog_primitive_count": len(engine.core.CATALOG["primitives"]),
        "v2_schema_sha256": schema_hashes,
        "fixed_input": {
            "allow_decision": allowed["decision"],
            "deny_decision": denied["decision"],
            "deny_violation_codes": [
                item.get("code") for item in denied.get("violations", [])
            ],
            "malformed_decision": malformed["decision"],
            "malformed_fail_closed": malformed.get("fail_closed"),
        },
    }
    print(json.dumps(report, ensure_ascii=False, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
