# Privacy and data scope

The ECAS evaluation is a software-engineering benchmark. It did not recruit
human participants and does not intentionally contain production customer
records, production credentials, or private communications.

Request values and expected decisions in the benchmark were constructed for
the frozen evaluation. Email-like values found by the release scan use test or
invalid-example domains. Numeric values that resemble telephone, account, or
identifier formats are benchmark fixtures, source-document examples, hashes,
or model-generated test outputs; they are not asserted to describe real people.

Except for the corresponding-author contact intentionally provided in
`README.md`, the release review found no real personal email address in the
research records, API key, bearer token, private-key marker, PEM-certificate
marker, or local Windows user-profile name. The package intentionally retains
some historical absolute paths inside immutable provenance strings. These
paths are non-operational, are not used by the verifier, and do not include a
local user-profile name.

Hosted-provider raw response envelopes and reasoning traces were removed from
this public supplementary artifact. The full byte-preserving archive is reserved for the
editorial and reviewer process and is not the public supplementary file.
